package com.insurance.claim.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		/* Class.forName("com.mysql.jdbc.Driver");
		  Connection  conn = DriverManager.getConnection(
				  "jdbc:mysql://localhost:3306/test",
				  "root",
				  "root");*/
		
		 
		  Class.forName("oracle.jdbc.OracleDriver");
		  Connection conn = DriverManager.getConnection( "jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg602","training602");
		/*System.out.println("connected");*/
		return conn;
	}
	/*public static void main(String args[]) throws ClassNotFoundException, SQLException {
		DB.getConnection();
	}*/
}
