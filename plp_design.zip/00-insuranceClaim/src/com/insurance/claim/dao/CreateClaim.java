package com.insurance.claim.dao;

	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.insurance.claim.Connect;
	public class CreateClaim extends HttpServlet{
	
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
		{HttpSession session1=request.getSession(false); 
		
			 	
		String s=(String) session1.getAttribute("userName");
				
			response.setContentType("text/html");
			RequestDispatcher rd=null;
			Connection con=null;
			PreparedStatement pst=null;
			PreparedStatement pst1=null;
			
			String str=null;
			
	try {
				con=Connect.getconnect();
				Statement stmt=con.createStatement();
		        System.out.println("into");
				String reason=request.getParameter("reason");
				 String location=request.getParameter("location");
				 String city=request.getParameter("city");
				 String state=request.getParameter("state");
				 int zip=Integer.parseInt(request.getParameter("zip"));
				 String type=request.getParameter("domain");
				System.out.println(type);
				
			
				String sql="insert into Claim_table values(claim_no.nextval,?,?,?,?,?,?,p_no.nextval)";
		//------------------ADDDING CLAIM TABLE----------------------------
			System.out.println(sql);
				 pst=con.prepareStatement(sql);
					pst.setString(1,reason);
					pst.setString(2,location);
					pst.setString(3,city);
					pst.setString(4,state);
					pst.setInt(5,zip);
					pst.setString(6,type);
					
					int count=pst.executeUpdate();
					
				if(count==1)
				  {
					System.out.println("added the claim details "+count+" row");
					System.out.println(session1.getAttribute("session :"+"userName"));
				  }
				else
				  {
					System.out.println("Unable to add details into DB");
				  }	
					
		//-----------------	ADDING VIEW TABLE---------------------------
				
				
				String sql1="insert into viewdetails values(claim_no.nextval,p_no.nextval,?)";
				System.out.println(sql1);
					 pst1=con.prepareStatement(sql1);
					 pst1.setString(1,type);
					 int vcount=pst1.executeUpdate();
			if(vcount==1)
			{
				 System.out.println("added the view claim details "+vcount+" row");
				 System.out.println(session1.getAttribute("session :"+"userName"));
				 request.getRequestDispatcher("/questions.jsp").include(request, response);
			}
			else
			{
				System.out.println("Unable to add --view-- details into DB");
			}
			}
			catch (Exception e)
			{ System.out.println(e);}
			
			
		}
		
	}







